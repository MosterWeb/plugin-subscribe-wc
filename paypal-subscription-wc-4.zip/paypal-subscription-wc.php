<?php
/**
 * Plugin Name: PayPal Subscription for WooCommerce
 * Description: Plugin para integrar suscripciones de PayPal en WooCommerce.
 * Version: 1.0.0
 * Author: Genius
 * Text Domain: paypal-subscription-wc
 */

if (!defined('ABSPATH')) {
    exit; // Bloquear acceso directo
}

// Definir constantes del plugin
define('PSWC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PSWC_PLUGIN_PATH', plugin_dir_path(__FILE__));


// Incluir archivos principales
require_once PSWC_PLUGIN_PATH . 'includes/admin-settings.php'; // Configuración general
require_once PSWC_PLUGIN_PATH . 'includes/product-fields.php'; // Campos personalizados en productos
require_once PSWC_PLUGIN_PATH . 'includes/payment-gateway.php'; // Método de pago personalizado: botón que manda el fetch con el idSubscription
require_once PSWC_PLUGIN_PATH . 'includes/ipn-handler.php'; // Manejo de notificaciones IPN: Lugar donde se crea el endpoint del fetch que manda el idSubscription

// Registrar y cargar el script en el checkout


// Activar el plugin
function pswc_activate_plugin() {
    // Agregar lógica de activación si es necesario
}
register_activation_hook(__FILE__, 'pswc_activate_plugin');

// Desactivar el plugin
function pswc_deactivate_plugin() {
    // Agregar lógica de desactivación si es necesario
}
register_deactivation_hook(__FILE__, 'pswc_deactivate_plugin');
