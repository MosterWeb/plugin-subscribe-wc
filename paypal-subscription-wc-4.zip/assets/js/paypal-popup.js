 

jQuery(document).ready(function ($) {
    const form = $("form.checkout");
    const paymentMethodInput = $('input[name="payment_method"]');
    // Quitar el ID del botón de submit (place_holder) antes de mostrar el popup
    const submitButton = $("#place_holder"); // El botón con ID place_holder


    function applyPaypalButtonChanges() {
      $(".place-order button, #place_order")
          .addClass('paypal_subscription_genius') // Agrega la clase personalizada
          .attr("data-value", "Subscríbete por PayPal") // Cambia el valor de data-value
          .text("Subscríbete por PayPal") // Cambia el texto del botón
          .attr("type", "button"); // Cambia el tipo del botón a 'button'

      // Mostrar el modal de PayPal si es necesario
      
  }
        
          // Evento de cambio de método de pago
    jQuery( document.body ).on( 'updated_checkout', function() {
        var choosenPaymentMethod = $('input[name^="payment_method"]:checked').val();
        if (choosenPaymentMethod === "paypal_subscription") {
            applyPaypalButtonChanges(); // Aplica los cambios si es el método de pago
        }
    });

        
           // Comprobación del método de pago seleccionado al cargar la página
    // Comprobación del método de pago seleccionado al cargar la página
    function checkInitialPaymentMethod() {
        // Esto se ejecuta después de un pequeño retraso
        setTimeout(function () {
            var initialPaymentMethod = $('input[name^="payment_method"]:checked').val();
            console.log("Método de pago seleccionado:", initialPaymentMethod); // Diagnóstico

            if (initialPaymentMethod === "paypal_subscription") {
                     
                applyPaypalButtonChanges(); // Aplica los cambios si es el método de pago
            }
        }, 1500); // Incrementa el tiempo si es necesario para esperar que se carguen todos los elementos de la página
    }


   
    // Evento para cuando se cambia el método de pago
    form.on("change", 'input[name^="payment_method"]', function () {
      var choosenPaymentMethod = $('input[name^="payment_method"]:checked').val();

      if (choosenPaymentMethod == "paypal_subscription") {
          applyPaypalButtonChanges(); // Aplica los cambios al botón
          showPaypalPopup();
      } else {
          // Revertir los cambios si no se selecciona 'paypal_subscription'
          $(".place-order button, #place_order").removeClass('paypal_subscription_genius')
              .attr("type", "submit"); // Revertir el tipo del botón a 'submit'
      }
  });

      
   // Llamar a la función de comprobación al cargar la página
    checkInitialPaymentMethod();
          
    // Delegar el evento click a todos los botones con la clase 'paypal_subscription_genius'
    $(document).on('click', '#place_order.paypal_subscription_genius', function (e) {
      e.preventDefault(); // Detener el envío del formulario
      e.stopImmediatePropagation(); // Prevenir propagación de otros eventos
  
      // Mostrar el popup de PayPal
      showPaypalPopup();
    });
  
  
  
    // Interceptar el envío del formulario
   // Selecciona el botón con el ID 'place_order' o la clase '.place-order button'
  
    // Crear dinámicamente el popup de PayPal
    function showPaypalPopup() {
      if ($("#paypal-popup").length === 0) {
        $("body").append(`
                  <style>
                  #paypal-popup-close:hover{
                      background-color: #195f8d;
                  }
                  </style>
                  <div id="paypal-popup" style="display: none; z-index: 1000; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: #2c2e2f;; color: white; text-align: center; padding: 20px;">
                      <div id="paypal_plan" style="background: white; padding: 20px; border-radius: 4px; width: 90%; max-width: 600px; margin: 0 auto; text-align: center; position: relative; top: 20%; transform: translate-x(-50%);">
                          <p style="color: black">Suscríbete a la donación. Puedes hacerlo a través de PayPal o con tarjeta de débito o crédito.</p>
                          <!-- Aquí iría el botón de PayPal -->
                          <div id="paypal-button-container" style="margin-bottom: 20px;"></div>
                          <button id="paypal-popup-close" style="padding: 10px 20px; background: #0070ba; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: 700; width: 100%; height: 43px;">Salir</button>
                      </div>
                  </div>
              `);
      }
  
      // Mostrar el popup
      $("#paypal-popup").fadeIn();
  
      // Si el botón de PayPal aún no ha sido renderizado
      if (!$("#paypal-popup").data("rendered")) {
        paypal
          .Buttons({
            createSubscription: function (data, actions) {
              return actions.subscription.create({
                plan_id: pswc_data.plan_id,
              });
            },
            onApprove: function (data) {
              console.log("Suscripción aprobada:", data.subscriptionID);
  
              console.log("Subscription ID:", data.subscriptionID);
              console.log(
                $("form.checkout")
                  .find('input[name="paypal_subscription_id"]')
                  .val()
              );
  
              // Agregar el subscriptionID al formulario antes de enviarlo
              $("<input>")
                .attr({
                  type: "hidden",
                  name: "paypal_subscription_id",
                  value: data.subscriptionID,
                })
                .appendTo("form.checkout");
  
              // Enviar el formulario
              $("form.checkout").submit();
            },
            onError: function (err) {
              alert("Error con PayPal: " + err);
            },
          })
          .render("#paypal-button-container"); // Renderizar el botón dentro del contenedor
  
        // Marcar como renderizado para no repetir la acción
        $("#paypal-popup").data("rendered", true);
      }
  
      jQuery(document).on("click", "#paypal-popup-close", function () {
        jQuery("#paypal-popup").fadeOut();
      });
    }
  });
  