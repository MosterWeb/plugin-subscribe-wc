<?php
if (!defined('ABSPATH')) {
    exit;
}

// Agregar un menú en el panel de administración
add_action('admin_menu', 'pswc_add_admin_menu');

function pswc_add_admin_menu() {
    add_menu_page(
        'PayPal Subscription Settings',
        'PayPal Subscriptions',
        'manage_options',
        'pswc-settings',
        'pswc_settings_page',
        PSWC_PLUGIN_URL . 'assets/icon.png',
        56
    );
}

// Mostrar la página de configuración
function pswc_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('PayPal Subscription Settings', 'paypal-subscription-wc'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('pswc_settings_group');
            do_settings_sections('pswc-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Registrar configuraciones
add_action('admin_init', 'pswc_register_settings');

function pswc_register_settings() {
    register_setting('pswc_settings_group', 'pswc_client_id');
    add_settings_section(
        'pswc_main_section',
        __('Configuración General', 'paypal-subscription-wc'),
        null,
        'pswc-settings'
    );

    add_settings_field(
        'pswc_client_id',
        __('Client ID de PayPal', 'paypal-subscription-wc'),
        'pswc_client_id_field',
        'pswc-settings',
        'pswc_main_section'
    );
}

function pswc_client_id_field() {
    $client_id = get_option('pswc_client_id', '');
    echo '<input type="text" name="pswc_client_id" value="' . esc_attr($client_id) . '" style="width: 100%;">';
}
