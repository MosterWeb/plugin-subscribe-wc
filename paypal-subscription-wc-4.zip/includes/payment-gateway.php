<?php
if (!defined('ABSPATH')) {
    exit;
}

// Registrar el método de pago personalizado
add_filter('woocommerce_payment_gateways', 'pswc_register_payment_gateway');
function pswc_register_payment_gateway($gateways)
{
    $gateways[] = 'WC_Gateway_PayPal_Subscription';
    return $gateways;
}

// Inicializar la clase del método de pago
add_action('plugins_loaded', 'pswc_init_payment_gateway');
function pswc_init_payment_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return; // Salir si WooCommerce no está activo
    }

    class WC_Gateway_PayPal_Subscription extends WC_Payment_Gateway
    {

        public function __construct()
        {
            $this->id = 'paypal_subscription';
            $this->icon = PSWC_PLUGIN_URL . 'assets/icon.png';
            $this->has_fields = true;
            $this->method_title = __('PayPal Subscription', 'paypal-subscription-wc');
            $this->method_description = __('Paga tus suscripciones con PayPal.', 'paypal-subscription-wc');

            // Configuraciones del método de pago
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');

            // Guardar configuraciones
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        // Campos del administrador
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Activar/Desactivar', 'paypal-subscription-wc'),
                    'type' => 'checkbox',
                    'label' => __('Activar PayPal Subscription', 'paypal-subscription-wc'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Título', 'paypal-subscription-wc'),
                    'type' => 'text',
                    'description' => __('El título que aparecerá en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('PayPal Subscription', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Descripción', 'paypal-subscription-wc'),
                    'type' => 'textarea',
                    'description' => __('El texto que se mostrará debajo del método de pago en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('Paga tu suscripción usando PayPal.', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
            );
        }

        // Forzar disponibilidad del método de pago
        public function is_available()
        {
            return true; // Forzar que el método de pago esté siempre disponible
        }

        // Mostrar el formulario de pago en finalizar compra
        public function payment_fields()
        {
            // Obtener el Client ID de las opciones del plugin
            $client_id = get_option('pswc_client_id', '');
            $plan_id = '';

            echo '<div style="padding: 15px; border-radius: 5px; text-align: center; font-size: 16px; color: #333;">
                <p>' . __('Suscríbete a la donación. Puedes hacerlo a través de PayPal o con tarjeta de débito o crédito.', 'paypal-subscription-wc') . '</p>
              </div>';

            // Buscar el plan_id en el carrito
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product_id = $cart_item['product_id'];
                $plan_id = get_post_meta($product_id, '_paypal_plan_id', true);
                if (!empty($plan_id)) {
                    break;
                }
            }

            // Mostrar un mensaje si faltan datos
            if (empty($client_id)) {
                echo '<p style="color: red;">' . __('Falta configurar el Client ID de PayPal en las opciones del plugin.', 'paypal-subscription-wc') . '</p>';
            }

            if (empty($plan_id)) {
                echo '<p style="color: red;">' . __('No hay un plan de suscripción asociado a este producto.', 'paypal-subscription-wc') . '</p>';
            }

            // Pasar datos dinámicos a JavaScript
            wp_enqueue_script('pswc-popup-script', plugin_dir_url(__FILE__) . '../assets/js/paypal-popup.js', ['jquery'], '1.0', true);

            // Aquí incluimos el script de PayPal directamente en la página
            wp_enqueue_script('paypal-sdk', 'https://www.paypal.com/sdk/js?client-id=' . esc_js($client_id) . '&vault=true&intent=subscription', [], null, true);

            wp_localize_script('pswc-popup-script', 'pswc_data', [
                'client_id' => $client_id,
                'plan_id'   => $plan_id,
                'error'     => empty($client_id) || empty($plan_id) ? 'No se pudo obtener el ID del plan o el Client ID.' : '',
            ]);
        }





        // Procesar el pago (redirigir a la página de agradecimiento)
        public function process_payment($order_id)
        {
            // Verificar si el subscription_id está llegando correctamente
            if (isset($_POST['paypal_subscription_id']) && !empty($_POST['paypal_subscription_id'])) {
                $subscription_id = sanitize_text_field($_POST['paypal_subscription_id']);
            } else {
                wc_add_notice(__('Error: El ID de suscripción no fue recibido.', 'paypal-subscription-wc'), 'error');
                return;
            }

            $order = wc_get_order($order_id);
            $order->update_status('processing', __('Suscripción confirmada.', 'paypal-subscription-wc'));
            update_post_meta($order_id, '_paypal_subscription_id', $subscription_id);

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_order_received_url(),
            );
        }
    }
}
