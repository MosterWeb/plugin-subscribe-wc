<?php
if (!defined('ABSPATH')) {
    exit; // Bloquear acceso directo
}

// Agregar columna para mostrar el Subscription ID en la tabla de pedidos
add_filter('manage_edit-shop_order_columns', 'add_subscription_column');
function add_subscription_column($columns) {
    $columns['paypal_subscription'] = __('PayPal Subscription ID', 'paypal-subscription-wc');
    return $columns;
}

// Rellenar la columna con el Subscription ID
add_action('manage_shop_order_posts_custom_column', 'fill_subscription_column', 10, 2);
function fill_subscription_column($column, $post_id) {
    if ($column === 'paypal_subscription') {
        $subscription_id = get_post_meta($post_id, '_paypal_subscription_id', true);
        echo $subscription_id ? esc_html($subscription_id) : __('N/A', 'paypal-subscription-wc');
    }
}

// Crear endpoint REST para guardar el Subscription ID
add_action('rest_api_init', function() {
    register_rest_route('api', '/save-subscription', array(
        'methods' => 'POST',
        'callback' => 'guardar_subscription_paypal',
        'permission_callback' => '__return_true',
    ));
});

function guardar_subscription_paypal($request) {
    $subscription_id = sanitize_text_field($request->get_param('subscriptionID'));
    $order_id = sanitize_text_field($request->get_param('orderID'));

    // Guardar el Subscription ID en el pedido
    if ($order_id && $subscription_id) {
        update_post_meta($order_id, '_paypal_subscription_id', $subscription_id);

        // Marcar el pedido como "procesado"
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_status('processing', __('Pago de suscripción recibido.', 'paypal-subscription-wc'));
            $order->add_order_note(__('Suscripción PayPal ID: ', 'paypal-subscription-wc') . $subscription_id);
        }

        return rest_ensure_response(['success' => true, 'message' => __('Suscripción guardada con éxito.', 'paypal-subscription-wc')]);
    }

    return new WP_Error('error', __('Faltan datos.', 'paypal-subscription-wc'), ['status' => 400]);
}

// Manejar notificaciones IPN de PayPal
add_action('wp', 'process_paypal_ipn');

function process_paypal_ipn() {
    if (isset($_GET['pay_gate_listener']) && $_GET['pay_gate_listener'] === 'paypal_ipn') {
        // Leer y procesar los datos IPN
        $raw_post_data = file_get_contents('php://input');
        parse_str($raw_post_data, $ipn_data);

        // Verificar el IPN con PayPal
        $verification = wp_remote_post('https://ipnpb.paypal.com/cgi-bin/webscr', array(
            'body' => array_merge(['cmd' => '_notify-validate'], $ipn_data),
        ));

        if (!is_wp_error($verification) && $verification['body'] === 'VERIFIED') {
            // Procesar los datos de la suscripción
            if (isset($ipn_data['txn_type']) && $ipn_data['txn_type'] === 'recurring_payment') {
                $subscription_id = $ipn_data['recurring_payment_id'];
                $payment_status = $ipn_data['payment_status'];
                $order_id = get_order_id_by_subscription($subscription_id);

                if ($order_id && $payment_status === 'Completed') {
                    $order = wc_get_order($order_id);
                    if ($order) {
                        $order->add_order_note(__('Pago recurrente recibido.', 'paypal-subscription-wc'));
                    }
                }
            }
        }

        exit;
    }
}

// Obtener el ID del pedido usando el Subscription ID
function get_order_id_by_subscription($subscription_id) {
    global $wpdb;

    $order_id = $wpdb->get_var($wpdb->prepare("
        SELECT post_id FROM $wpdb->postmeta
        WHERE meta_key = '_paypal_subscription_id' AND meta_value = %s
        LIMIT 1
    ", $subscription_id));

    return $order_id;
}


// https://tu-dominio.com/?pay_gate_listener=paypal_ipn
