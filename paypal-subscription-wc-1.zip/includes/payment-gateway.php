<?php
if (!defined('ABSPATH')) {
    exit;
}

// Registrar el método de pago personalizado
add_filter('woocommerce_payment_gateways', 'pswc_register_payment_gateway');
function pswc_register_payment_gateway($gateways)
{
    $gateways[] = 'WC_Gateway_PayPal_Subscription';
    return $gateways;
}

// Inicializar la clase del método de pago
add_action('plugins_loaded', 'pswc_init_payment_gateway');
function pswc_init_payment_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return; // Salir si WooCommerce no está activo
    }

    class WC_Gateway_PayPal_Subscription extends WC_Payment_Gateway
    {

        public function __construct()
        {
            $this->id = 'paypal_subscription';
            $this->icon = PSWC_PLUGIN_URL . 'assets/icon.png';
            $this->has_fields = true;
            $this->method_title = __('PayPal Subscription', 'paypal-subscription-wc');
            $this->method_description = __('Paga tus suscripciones con PayPal.', 'paypal-subscription-wc');

            // Configuraciones del método de pago
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');

            // Guardar configuraciones
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        // Campos del administrador
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Activar/Desactivar', 'paypal-subscription-wc'),
                    'type' => 'checkbox',
                    'label' => __('Activar PayPal Subscription', 'paypal-subscription-wc'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Título', 'paypal-subscription-wc'),
                    'type' => 'text',
                    'description' => __('El título que aparecerá en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('PayPal Subscription', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Descripción', 'paypal-subscription-wc'),
                    'type' => 'textarea',
                    'description' => __('El texto que se mostrará debajo del método de pago en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('Paga tu suscripción usando PayPal.', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
            );
        }

        // Forzar disponibilidad del método de pago
        public function is_available()
        {
            return true; // Forzar que el método de pago esté siempre disponible
        }

        // Mostrar el formulario de pago en finalizar compra
        public function payment_fields()
        {
            $client_id = get_option('pswc_client_id', '');
            $plan_id = '';

            // Buscar el plan_id en el carrito
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product_id = $cart_item['product_id'];
                $plan_id = get_post_meta($product_id, '_paypal_plan_id', true);
                if (!empty($plan_id)) {
                    break;
                }
            }

            // Mostrar mensajes si faltan configuraciones importantes
            if (empty($client_id)) {
                echo '<p style="color: red;">' . __('Falta configurar el Client ID de PayPal en las opciones del plugin.', 'paypal-subscription-wc') . '</p>';
            }

            if (empty($plan_id)) {
                echo '<p style="color: red;">' . __('No hay un plan de suscripción asociado a este producto.', 'paypal-subscription-wc') . '</p>';
            }

            if (!empty($client_id) && !empty($plan_id)) {
                // Renderizar el botón de suscripción
?>
                <div id="paypal-button-container"></div>
                <script src="https://www.paypal.com/sdk/js?client-id=<?php echo esc_js($client_id); ?>&vault=true&intent=subscription"></script>
                <script>
                    jQuery(document).ready(function($) {
                        if ($('#paypal-button-container').length) {
                            paypal.Buttons({
                                style: {
                                    shape: 'rect',
                                    color: 'gold',
                                    layout: 'vertical',
                                    label: 'subscribe'
                                },
                                createSubscription: function(data, actions) {
                                    return actions.subscription.create({
                                        plan_id: '<?php echo esc_js($plan_id); ?>' // PHP dinámico aquí
                                    });
                                },
                                onApprove: function(data, actions) {
                                    fetch('<?php echo esc_url(site_url()); ?>/wp-json/api/save-subscription', {
                                            method: 'POST',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                subscriptionID: data.subscriptionID,
                                                orderID: '<?php echo esc_js(WC()->session->get("order_awaiting_payment")); ?>' // PHP dinámico aquí
                                            })
                                        })
                                        .then(response => response.json())
                                        .then(data => console.log('Suscripción completada:', data))
                                        .catch(error => console.error('Error al guardar la suscripción:', error));
                                }
                            }).render('#paypal-button-container');
                        } else {
                            console.error('El contenedor #paypal-button-container no existe.');
                        }
                    });
                </script>

<?php
            }
        }

        // Procesar el pago (redirigir a la página de agradecimiento)
        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);

            // Actualizar el estado del pedido
            $order->update_status('on-hold', __('Esperando confirmación de PayPal.', 'paypal-subscription-wc'));

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_order_received_url(),
            );
        }
    }
}
