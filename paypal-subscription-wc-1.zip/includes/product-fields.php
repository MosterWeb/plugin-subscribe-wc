<?php
if (!defined('ABSPATH')) {
    exit;
}

// Agregar campo personalizado en la página del producto
add_action('woocommerce_product_options_general_product_data', 'pswc_add_plan_id_field');

function pswc_add_plan_id_field() {
    woocommerce_wp_text_input(array(
        'id'          => '_paypal_plan_id',
        'label'       => __('PayPal Plan ID', 'paypal-subscription-wc'),
        'placeholder' => __('Introduce el PayPal Plan ID'),
        'description' => __('El ID del plan de suscripción generado en PayPal.'),
        'desc_tip'    => true,
    ));
}

// Guardar el campo personalizado
add_action('woocommerce_process_product_meta', 'pswc_save_plan_id_field');

function pswc_save_plan_id_field($post_id) {
    $plan_id = isset($_POST['_paypal_plan_id']) ? sanitize_text_field($_POST['_paypal_plan_id']) : '';
    update_post_meta($post_id, '_paypal_plan_id', $plan_id);
}
