<?php
if (!defined('ABSPATH')) {
    exit;
}

// Mostrar el botón en la página de finalizar compra
add_action('woocommerce_review_order_after_submit', 'pswc_show_paypal_button');

function pswc_show_paypal_button() {
    $client_id = get_option('pswc_client_id', '');
    if (empty($client_id)) {
        return; // No mostrar botón si no hay Client ID configurado
    }

    // Buscar el plan_id en el carrito
    $plan_id = '';
    foreach (WC()->cart->get_cart() as $cart_item) {
        $product_id = $cart_item['product_id'];
        $plan_id = get_post_meta($product_id, '_paypal_plan_id', true);
        if (!empty($plan_id)) {
            break;
        }
    }

    if (empty($plan_id)) {
        return;
    }

    // Renderizar el botón de PayPal
    ?>
    <div id="paypal-button-container"></div>
    <script src="https://www.paypal.com/sdk/js?client-id=<?php echo esc_js($client_id); ?>&vault=true&intent=subscription"></script>
    <script>
        paypal.Buttons({
            style: {
                shape: 'rect',
                color: 'gold',
                layout: 'vertical',
                label: 'subscribe'
            },
            createSubscription: function(data, actions) {
                return actions.subscription.create({
                    plan_id: '<?php echo esc_js($plan_id); ?>'
                });
            },
            onApprove: function(data, actions) {
                fetch('<?php echo site_url(); ?>/wp-json/api/save-subscription', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        subscriptionID: data.subscriptionID,
                        orderID: '<?php echo WC()->session->get("order_awaiting_payment"); ?>'
                    })
                })
                .then(response => response.json())
                .then(data => console.log('Suscripción completada:', data))
                .catch(error => console.error('Error:', error));
            }
        }).render('#paypal-button-container');
    </script>
    <?php
}
