<?php
if (!defined('ABSPATH')) {
    exit;
}

// Registrar el método de pago personalizado
add_filter('woocommerce_payment_gateways', 'pswc_register_payment_gateway');
function pswc_register_payment_gateway($gateways)
{
    $gateways[] = 'WC_Gateway_PayPal_Subscription';
    return $gateways;
}

// Inicializar la clase del método de pago
add_action('plugins_loaded', 'pswc_init_payment_gateway');
function pswc_init_payment_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return; // Salir si WooCommerce no está activo
    }

    class WC_Gateway_PayPal_Subscription extends WC_Payment_Gateway
    {

        public function __construct()
        {
            $this->id = 'paypal_subscription';
            $this->icon = PSWC_PLUGIN_URL . 'assets/icon.png';
            $this->has_fields = true;
            $this->method_title = __('PayPal Subscription', 'paypal-subscription-wc');
            $this->method_description = __('Paga tus suscripciones con PayPal.', 'paypal-subscription-wc');

            // Configuraciones del método de pago
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');

            // Guardar configuraciones
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        // Campos del administrador
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Activar/Desactivar', 'paypal-subscription-wc'),
                    'type' => 'checkbox',
                    'label' => __('Activar PayPal Subscription', 'paypal-subscription-wc'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Título', 'paypal-subscription-wc'),
                    'type' => 'text',
                    'description' => __('El título que aparecerá en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('PayPal Subscription', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Descripción', 'paypal-subscription-wc'),
                    'type' => 'textarea',
                    'description' => __('El texto que se mostrará debajo del método de pago en la página de finalizar compra.', 'paypal-subscription-wc'),
                    'default' => __('Paga tu suscripción usando PayPal.', 'paypal-subscription-wc'),
                    'desc_tip' => true,
                ),
            );
        }

        // Forzar disponibilidad del método de pago
        public function is_available()
        {
            return true; // Forzar que el método de pago esté siempre disponible
        }

        // Mostrar el formulario de pago en finalizar compra
        public function payment_fields()
        {
            // Obtener el Client ID de las opciones del plugin
            $client_id = get_option('pswc_client_id', '');
            $plan_id = '';

            echo '<div style="padding: 15px; border-radius: 5px; text-align: center; font-size: 16px; color: #333;">
                <p>' . __('Suscríbete a la donación. Puedes hacerlo a través de PayPal o con tarjeta de débito o crédito.', 'paypal-subscription-wc') . '</p>
              </div>';

            // Buscar el plan_id en el carrito
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product_id = $cart_item['product_id'];
                $plan_id = get_post_meta($product_id, '_paypal_plan_id', true);
                if (!empty($plan_id)) {
                    break;
                }
            }
            // Mostrar un mensaje si faltan datos
            if (empty($client_id)) {
                echo '<p style="color: red;">' . __('Falta configurar el Client ID de PayPal en las opciones del plugin.', 'paypal-subscription-wc') . '</p>';
            }

            if (empty($plan_id)) {
                echo '<p style="color: red;">' . __('No hay un plan de suscripción asociado a este producto.', 'paypal-subscription-wc') . '</p>';
            }

            // Pasar datos dinámicos a JavaScript
            wp_enqueue_script('pswc-popup-script', plugin_dir_url(__FILE__) . '../assets/js/paypal-popup.js', ['jquery'], '1.0', true);

            // Aquí incluimos el script de PayPal directamente en la página
            wp_enqueue_script('paypal-sdk', 'https://www.paypal.com/sdk/js?client-id=' . esc_js($client_id) . '&vault=true&intent=subscription', [], null, true);

            wp_localize_script('pswc-popup-script', 'pswc_data', [
                'client_id' => $client_id,
                'plan_id'   => $plan_id,
                'error'     => empty($client_id) || empty($plan_id) ? 'No se pudo obtener el ID del plan o el Client ID.' : '',
            ]);
        }



        public function process_payment($order_id) {
    // Verificar el contenido de $_POST
    error_log('Contenido de $_POST: ' . print_r($_POST, true));  // Esto imprimirá todo lo que llega en la solicitud POST
    
    // Verificar si el paypal_subscription_id está presente en $_POST
    if (isset($_POST['paypal_subscription_id']) && !empty($_POST['paypal_subscription_id'])) {
        $subscription_id = sanitize_text_field($_POST['paypal_subscription_id']);
        
        // Registrar en los logs el ID de suscripción recibido
        error_log('ID de suscripción recibido: ' . $subscription_id); // Verificar que el ID se está recibiendo
        
        // Obtener el pedido de WooCommerce
        $order = wc_get_order($order_id);

        // Guardar el ID de la suscripción como meta del pedido
        update_post_meta($order_id, '_paypal_subscription_id', $subscription_id);

          // Cambiar el estado del pedido a 'pago comlpetado'
                $order->update_status('completed', __('Suscripción confirmada y pago completado.', 'paypal-subscription-wc'));


        // Completar el pago
        $order->payment_complete($subscription_id);

        // Agregar mensaje de éxito
        wc_add_notice(__('La suscripción fue todo un éxito.', 'paypal-subscription-wc'), 'success');

        // Registrar en los logs que el pedido se procesó correctamente
        error_log('Pedido procesado correctamente. ID de pedido: ' . $order_id);

        // Redirigir al usuario a la página de "gracias"
        return array(
            'result' => 'success',
            'redirect' => $order->get_checkout_order_received_url(),
        );
    }
    
    // Si no se recibe el ID de suscripción, agregar un log y un mensaje de error
    error_log('No se recibió el ID de suscripción en $_POST');
    wc_add_notice(__('Error: El ID de suscripción no fue recibido.', 'paypal-subscription-wc'), 'error');
    
    // Redirigir al usuario al carrito
    return array(
        'result' => 'failure',
        'redirect' => wc_get_cart_url(),
    );
}

    }
}



add_action('woocommerce_checkout_update_order_meta', 'guardar_paypal_subscription_id', 10, 2);

function guardar_paypal_subscription_id($order_id, $data) {
    if (!empty($_POST['paypal_subscription_id'])) {
        $subscription_id = sanitize_text_field($_POST['paypal_subscription_id']);
        update_post_meta($order_id, '_paypal_subscription_id', $subscription_id);
    }
}


//Obtener la proxima fecha de pago

function get_next_payment_date($subscription_id) {
    // Simulación: Ajusta esto si usas WooCommerce Subscriptions o algún plugin de manejo de suscripciones
    if (!$subscription_id) {
        return null;
    }

    // Aquí podrías hacer una consulta real a PayPal API o al sistema de WooCommerce
    // Simula una fecha como prueba
    $next_payment_timestamp = strtotime('+30 days'); // Agrega 30 días
    $next_payment_date = date('Y-m-d', $next_payment_timestamp);

    return $next_payment_date;
}



//Detalles de la pagina de agradeciemiento

add_action('woocommerce_thankyou', 'mostrar_datos_suscripcion_paypal', 20, 1);

function mostrar_datos_suscripcion_paypal($order_id) {
    $order = wc_get_order($order_id);

    if (!$order) {
        echo '<p>No se encontró información del pedido.</p>';
        return;
    }

    $paypal_subscription_id = get_post_meta($order_id, '_paypal_subscription_id', true);

    if ($paypal_subscription_id) {
        echo '<h3>Detalles de tu suscripción:</h3>';
        echo '<p><strong>Subscription ID:</strong> ' . esc_html($paypal_subscription_id) . '</p>';

        // Obtener la próxima fecha de pago
        $next_payment_date = get_next_payment_date($paypal_subscription_id);

        if ($next_payment_date) {
            echo '<p><strong>Próximo pago:</strong> ' . esc_html($next_payment_date) . '</p>';
        } else {
            echo '<p>No se pudo determinar la fecha del próximo pago.</p>';
        }
    } else {
        echo '<p>No se encontró un Subscription ID para este pedido.</p>';
    }
}




//Genera los datos de suscripción en la página Mi cuenta: 
// 1. Agregar un nuevo endpoint a la sección "Mi cuenta"
// 1. Registrar el endpoint para WooCommerce
add_action('init', 'registrar_endpoint_suscripcion');
function registrar_endpoint_suscripcion() {
    add_rewrite_endpoint('suscripcion-paypal', EP_ROOT | EP_PAGES);
}

// 2. Agregar el enlace "Mi Suscripción PayPal" al menú de "Mi Cuenta"
add_filter('woocommerce_account_menu_items', 'agregar_menu_suscripcion', 10, 1);
function agregar_menu_suscripcion($items) {
    // Insertar el nuevo item en el menú después de 'Pedidos'
    $suscripcion_url = wc_get_account_endpoint_url('suscripcion-paypal');
    $items = array_slice($items, 0, array_search('orders', array_keys($items)) + 1, true) + 
             array('suscripcion-paypal' => __('Mi Suscripción PayPal', 'text-domain')) + 
             array_slice($items, array_search('orders', array_keys($items)) + 1, null, true);

    return $items;
}


// 3. Contenido del endpoint
add_action('woocommerce_account_suscripcion-paypal_endpoint', 'mostrar_datos_suscripcion');
function mostrar_datos_suscripcion() {
    $user_id = get_current_user_id();

    if (!$user_id) {
        echo '<p>No se encontró información del usuario.</p>';
        return;
    }

    // Recuperar pedidos del usuario
    $customer_orders = wc_get_orders([
        'customer' => $user_id,
        'status' => 'completed',
        'limit' => -1,
    ]);

    if (empty($customer_orders)) {
        echo '<p>No tienes suscripciones activas asociadas.</p>';
        return;
    }

    // Crear tabla para mostrar las suscripciones
    echo '<table style="width: 100%; border-collapse: collapse; margin-top: 20px;">';
    echo '<thead><tr><th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4;">Pedido</th><th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4;">Plan</th><th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4;">Subscription ID</th><th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4;">Próximo Pago</th></tr></thead>';
    echo '<tbody>';

    // Mostrar suscripciones con PayPal Subscription ID
    foreach ($customer_orders as $order) {
        $paypal_subscription_id = $order->get_meta('_paypal_subscription_id');

        if ($paypal_subscription_id) {
            // Obtener el nombre del producto del pedido (producto principal)
            $items = $order->get_items();
            $product_name = '';
            foreach ($items as $item) {
                $product_name = $item->get_name();  // Obtener el nombre del producto
            }

            // Obtener la próxima fecha de pago
            $next_payment_date = get_next_payment_date($paypal_subscription_id);

            echo '<tr>';
            echo '<td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($order->get_id()) . '</td>';
            echo '<td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($product_name) . '</td>';
            echo '<td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($paypal_subscription_id) . '</td>';
            echo '<td style="border: 1px solid #ddd; padding: 8px;">' . ($next_payment_date ? esc_html($next_payment_date) : 'No disponible') . '</td>';
            echo '</tr>';
        }
    }
    echo '</tbody>';
    echo '</table>';

    // Enlace para solicitar la cancelación de la suscripción
    echo '<p style="margin-top: 20px;"><a href="' . esc_url(get_permalink(get_page_by_path('contacto'))) . '?cancel_subscription=true" style="padding: 10px 20px; background-color: #0073aa; color: white; text-decoration: none; border-radius: 5px;">Solicitar cancelar la suscripción</a></p>';
}

// 4. Flush rewrite rules al activar el plugin/tema
add_action('after_switch_theme', 'flush_rewrite_rules');




//Mostrar datos del Id Subscriptiorn en el administrador
// Mostrar el Subscription ID en el panel de administración de WooCommerce
add_action('woocommerce_admin_order_data_after_order_details', 'agregar_subscription_id_admin');

function agregar_subscription_id_admin($order) {
    // Obtener el Subscription ID
    $paypal_subscription_id = $order->get_meta('_paypal_subscription_id');

    if ($paypal_subscription_id) {
        // Mostrar el Subscription ID en el panel de administración
        echo '<p style="margin-top: 30px;"><strong>' . __('Subscription ID', 'text-domain') . ':</strong> ' . esc_html($paypal_subscription_id) . '</p>';
    }
}








 