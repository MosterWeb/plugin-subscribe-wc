<?php
/**
 * Plugin Name: PayPal Subscription for WooCommerce
 * Description: Plugin para integrar suscripciones de PayPal en WooCommerce.
 * Version: 1.0.0
 * Author: Jason Rodríguez | <a href="https://wa.me/51928951828" target="_blank">+51 928 951 828</a> | <a href="https://portafolio.mosterweb.com/" target="_blank">MosterWeb.com</a>
 * Text Domain: paypal-subscription-wc
 */


if (!defined('ABSPATH')) {
    exit; // Bloquear acceso directo
}

// Definir constantes del plugin
define('PSWC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PSWC_PLUGIN_PATH', plugin_dir_path(__FILE__));


// Incluir archivos principales
require_once PSWC_PLUGIN_PATH . 'includes/admin-settings.php'; // Configuración general
require_once PSWC_PLUGIN_PATH . 'includes/product-fields.php'; // Campos personalizados en productos
require_once PSWC_PLUGIN_PATH . 'includes/payment-gateway.php'; // Método de pago personalizado: botón que manda el fetch con el idSubscription
require_once PSWC_PLUGIN_PATH . 'includes/ipn-handler.php'; // Manejo de notificaciones IPN: Lugar donde se crea el endpoint del fetch que manda el idSubscription

// Registrar y cargar el script en el checkout

// Función para activar el plugin
function pswc_activate_plugin() {
    // Registrar endpoint y limpiar reglas de reescritura
    add_rewrite_endpoint('suscripcion-paypal', EP_PAGES);
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'pswc_activate_plugin');

// Función para desactivar el plugin
function pswc_deactivate_plugin() {
    // Limpiar reglas de reescritura
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'pswc_deactivate_plugin');

